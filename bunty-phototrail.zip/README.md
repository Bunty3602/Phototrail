# Bunty Phototrail

This repository contains extended field logs and sensor data from various site visits around the world.

- Each folder under `locations/` represents a different site.
- Notes, CSVs, and dummy files contain random data to simulate real monitoring.
